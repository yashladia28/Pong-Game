#include <iostream>
#include <fstream>
#include "raylib.h"
using namespace std;

int main() {

    const int screenWidth = 800;
    const int screenHeight = 450;
    const int winScore = 10;
    InitWindow(screenWidth, screenHeight, "Pong");
    SetTargetFPS(60);
    InitAudioDevice();
    int rightVel = 2;
    float spinPower = 0.2;
    // Sound paddleSound = LoadSound("180.wav");
    // Sound wallSound   = LoadSound("180.wav");
    // Sound scoreSound  = LoadSound("180.wav");
    int HighScore = 0;
    ifstream fin("highscore.txt");
    if(fin.is_open()){
        fin>>HighScore;
        fin.close();
    }
    int gameMode = 0;

    Rectangle leftPaddle{10, 10, 10, 100};
    Rectangle rightPaddle{780, 10, 10, 100};

    Vector2 ballPos{400, 225};
    float ballRadius = 10;

    Vector2 ballVel{4, 4};
    int leftScore = 0;
    int rightScore = 0;
    bool gameOver = false;
    while (!WindowShouldClose()) {

        // -------- UPDATE --------
        if(gameOver){
            BeginDrawing();
            ClearBackground(BLACK);
            if(leftScore>=winScore){
                DrawText("Game Over! Player 1 Wins!",screenWidth/2-220,80,30,WHITE);
            }
            else if(gameMode == 1){
                DrawText("Game Over! Computer Wins!",screenWidth/2-220,80,30,WHITE);
            }
            else if(gameMode == 2){
                DrawText("Game Over! Player 2 Wins!",screenWidth/2-220,80,30,WHITE);
            }
            DrawText("Press ENTER to restart", 180, 250, 30, WHITE);

            EndDrawing();

            if(IsKeyPressed(KEY_ENTER)){
                gameMode = 0;
                gameOver = false;
                leftScore = 0;
                rightScore = 0;
                ballPos = { screenWidth/2.0f, screenHeight/2.0f };
                ballVel = {4, 4};
            }

            continue;
        }
        if(gameMode == 0){
            BeginDrawing();
            ClearBackground(BLACK);
            DrawText("PONG", screenWidth/2 - 80, 80, 60, WHITE);
            DrawText("Press 1 for Single Player", screenWidth/2 - 200, 200, 30, WHITE);
            DrawText("Press 2 for Two Players",   screenWidth/2 - 200, 250, 30, WHITE);
            DrawText(TextFormat("Press 3 Highscore Mode\n(Highscore: %d)",HighScore),   screenWidth/2 - 200, 300, 30, WHITE);

            EndDrawing();
            if(IsKeyPressed(KEY_ONE)) gameMode = 1;
            if(IsKeyPressed(KEY_TWO)) gameMode = 2;
            if(IsKeyPressed(KEY_THREE)) gameMode = 3;
            continue;
        }

        //AI Mode
        if (gameMode==1||gameMode==3)
        {
            /* code */
            if(ballVel.x>0 && ballPos.y<rightPaddle.y+rightPaddle.height/2){rightPaddle.y+=-1*rightVel;}
            else if(ballVel.x>0&&ballPos.y>rightPaddle.y+rightPaddle.height/2) {
                rightPaddle.y+=rightVel;
            }
        }
        
        // paddle input
        else if(gameMode == 2){
            
            float h2 = 0;


            if (IsKeyDown(KEY_UP))   h2 = -1;
            if (IsKeyDown(KEY_DOWN)) h2 =  1;


            rightPaddle.y += h2 * 6;

        }
        float h1 = 0;

        if (IsKeyDown(KEY_W)) h1 = -1;
        if (IsKeyDown(KEY_S)) h1 =  1;

        leftPaddle.y  += h1 * 6;
        // clamp
        if (leftPaddle.y < 0) leftPaddle.y = 0;
        if (leftPaddle.y + leftPaddle.height > screenHeight)
            leftPaddle.y = screenHeight - leftPaddle.height;

        if (rightPaddle.y < 0) rightPaddle.y = 0;
        if (rightPaddle.y + rightPaddle.height > screenHeight)
            rightPaddle.y = screenHeight - rightPaddle.height;

        // ball motion
        ballPos.x += ballVel.x;
        ballPos.y += ballVel.y;

        // wall bounce
        if (ballPos.y - ballRadius <= 0) {
            ballPos.y = ballRadius; 
            ballVel.y *= -1;
            // PlaySound(wallSound);
        }
        if (ballPos.y + ballRadius >= screenHeight) {
            ballPos.y = screenHeight - ballRadius;
            ballVel.y *= -1;
            // PlaySound(wallSound);
        }

        if(ballVel.x<0&&CheckCollisionCircleRec(ballPos,ballRadius,leftPaddle)) {
            // PlaySound(paddleSound);
            ballVel.x*=-1;
            ballPos.x = leftPaddle.x + leftPaddle.width + ballRadius;
            float hitPos = (ballPos.y - leftPaddle.y) - leftPaddle.height/2;
            ballVel.y = hitPos * spinPower;
            ballVel.x*=1.02f;
            ballVel.y*=1.02f;
        }
        if(ballVel.x>0&&CheckCollisionCircleRec(ballPos,ballRadius,rightPaddle)) {
            // PlaySound(paddleSound);
            ballVel.x*=-1;
            ballPos.x = rightPaddle.x-ballRadius;
            float hitPos = (ballPos.y - rightPaddle.y) - rightPaddle.height/2;
            ballVel.y = hitPos * 0.1f;

            ballVel.x*=1.05f;
            ballVel.y*=1.05f;

        }
        if(ballPos.x-ballRadius<0) {
            // PlaySound(scoreSound);
            rightScore++;
            ballPos = { screenWidth/2.0f, screenHeight/2.0f };
            ballVel.x =4;
            ballVel.y = 0;

        }
        if(ballPos.x+ballRadius>screenWidth) {
            // PlaySound(scoreSound);
            leftScore++;
            ballPos = { screenWidth/2.0f, screenHeight/2.0f };
            ballVel.x =-4;
            ballVel.y = 0;
            rightVel++;
            if(gameMode ==1 || gameMode ==3)spinPower *=1.05;
            if(gameMode == 3) {
                HighScore = max(HighScore,leftScore);
                ofstream fout("highscore.txt");
                fout<<HighScore;
                fout.close();
            }
        }
        if(gameMode!= 3 && (leftScore >= winScore||rightScore >=winScore)){
            gameOver = true;
            continue;
        }

        // -------- DRAW --------
        BeginDrawing();
        ClearBackground(BLACK);

        DrawRectangleRec(leftPaddle, WHITE);
        DrawRectangleRec(rightPaddle, WHITE);
        DrawCircleV(ballPos, ballRadius, WHITE);

        DrawText(TextFormat("%d",leftScore),200,40,40,WHITE);
        DrawText(TextFormat("%d",rightScore),600,40,40,WHITE);

        EndDrawing();
    }
    CloseAudioDevice();
    CloseWindow();
    return 0;
}
